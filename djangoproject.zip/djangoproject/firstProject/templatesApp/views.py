from django.shortcuts import render

# Create your views here.
def renderTemplate(request):
    myDict={"name":"Raghul Ramesh"}
    return render(request,'templatesApp/firstTemplate.html',context=myDict)

def renderEmployee(request):
    myDict={'id':1000,"name":"Rajesh","salary":10000}
    return render(request,'templatesApp/employeeTemplate.html',myDict)
