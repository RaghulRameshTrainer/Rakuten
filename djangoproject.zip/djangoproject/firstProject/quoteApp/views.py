from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def displayQuote(requst):
    return HttpResponse("The best inverstment we can make is in ouself!")
