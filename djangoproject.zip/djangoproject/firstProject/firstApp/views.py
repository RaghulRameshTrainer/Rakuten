from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(response):
    return HttpResponse('<h1> This is my first Django App! </h1>')

def displayDate(response):
    import datetime
    dt=datetime.datetime.now()
    s="<b>Current Date and Time :</b>"+str(dt)
    return HttpResponse(s)
